<footer class="footer">
  	 <div class="container">
  	 	<div class="row">
  	 		<div class="footer-col">
  	 			<h4>Về chúng tôi</h4>
  	 			<ul>
  	 				<li><a href="about.php">Câu chuyện thương hiệu</a></li>
  	 				<li><a href="#">Tin tức</a></li>
  	 				<li><a href="contact.php">Liên hệ</a></li>
  	 			</ul>
  	 		</div>
  	 		<div class="footer-col">
  	 			<h4>CHÍNH SÁCH BÁN HÀNG</h4>
  	 			<ul>
  	 				<li><a href="#">Chính sách đổi hàng</a></li>
  	 				<li><a href="#">Chính sách bảo hành</a></li>
  	 				<li><a href="#">Chính sách hội viên</a></li>
  	 				<li><a href="#">Hướng dẫn mua hàng</a></li>
  	 			</ul>
  	 		</div>
  	 		<div class="footer-col">
  	 			<h4>TƯ VẤN</h4>
  	 			<ul>
  	 				<li><a href="#">Tư vấn phong cách</a></li>
  	 				<li><a href="#">Tư vấn hỏi size</a></li>
  	 				<li><a href="#">Hỏi đáp</a></li>
  	 			</ul>
  	 		</div>
  	 		<div class="footer-col">
  	 			<h4>THEO DÕI CHÚNG TÔI TẠI</h4>
  	 			<div class="social-links">
  	 				<a href="#"><i class="fab fa-facebook-f"></i></a>
  	 				<a href="#"><i class="fab fa-twitter"></i></a>
  	 				<a href="#"><i class="fab fa-instagram"></i></a>
  	 				<a href="#"><i class="fab fa-linkedin-in"></i></a>
  	 			</div>
  	 		</div>
  	 	</div>
  	 </div>
  </footer>

<div class="loader">
   <img src="images/loader.gif" alt="">
</div>